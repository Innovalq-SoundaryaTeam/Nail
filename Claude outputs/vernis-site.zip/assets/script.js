(function(){
  var toggle = document.getElementById('navToggle');
  var links = document.getElementById('navLinks');

  if(toggle && links){
    toggle.addEventListener('click', function(){
      var open = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  var form = document.getElementById('bookingForm');
  var confirmBox = document.getElementById('confirmBox');
  var confirmTitle = document.getElementById('confirmTitle');
  var confirmBody = document.getElementById('confirmBody');

  if(form && confirmBox){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      if(!form.checkValidity()){ form.reportValidity(); return; }
      var data = new FormData(form);
      var name = (data.get('name') || '').toString().trim().split(' ')[0];
      var service = data.get('service');
      var date = data.get('date');
      var time = data.get('time');
      var prettyDate = '';
      try{
        var d = new Date(date + 'T00:00:00');
        prettyDate = d.toLocaleDateString('en-IN', { weekday:'short', day:'numeric', month:'short' });
      }catch(err){ prettyDate = date; }
      confirmTitle.textContent = 'Thanks, ' + (name || 'there') + ' — request received.';
      confirmBody.textContent = service + ' on ' + prettyDate + ' at ' + time + ". We'll confirm by call or WhatsApp within 2 hours at the number you shared.";
      form.style.display = 'none';
      confirmBox.style.display = 'block';
    });

    var again = document.getElementById('bookAnother');
    if(again){
      again.addEventListener('click', function(e){
        e.preventDefault();
        form.reset();
        form.style.display = 'flex';
        confirmBox.style.display = 'none';
      });
    }
  }

  // Gallery filter tabs
  var tabs = document.querySelectorAll('.filter-tab');
  var cards = document.querySelectorAll('.gallery-card');
  if(tabs.length && cards.length){
    tabs.forEach(function(tab){
      tab.addEventListener('click', function(){
        tabs.forEach(function(t){ t.classList.remove('active'); });
        tab.classList.add('active');
        var cat = tab.getAttribute('data-filter');
        cards.forEach(function(card){
          var match = cat === 'all' || card.getAttribute('data-category') === cat;
          card.hidden = !match;
        });
      });
    });
  }

  // Newsletter sign-up (client-side confirmation)
  var newsletterForm = document.getElementById('newsletterForm');
  if(newsletterForm){
    newsletterForm.addEventListener('submit', function(e){
      e.preventDefault();
      var input = newsletterForm.querySelector('input[type="email"]');
      var note = document.getElementById('newsletterNote');
      if(input && input.checkValidity() && note){
        note.textContent = "You're on the list — look out for the next drop in your inbox.";
        input.value = '';
      }
    });
  }
})();
